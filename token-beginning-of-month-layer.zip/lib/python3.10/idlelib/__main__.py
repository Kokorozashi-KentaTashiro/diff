"""
IDLE main entry point

Run IDLE as python -m idlelib
"""
import idlelib.pyshell
idlelib.pyshell.main()
# This file does not work for 2.7; See issue 24212.
